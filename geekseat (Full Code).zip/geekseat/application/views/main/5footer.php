                

                <!-- footer content -->
                <div class="right_col" style="height: 3px;">
                   <footer>
                    <div class="">
                        <p class="pull-right">Geekseat</p>
                    </div>
                    <div class="clearfix"></div>
                </footer> 
                </div>
                
                <!-- /footer content -->
            