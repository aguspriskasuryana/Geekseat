</div>

    </div>
    <script src="<?php echo base_url('asset'); ?>/js/bootstrap.min.js"></script>

    <!-- chart js -->
    <script src="<?php echo base_url('asset'); ?>/js/chartjs/chart.min.js"></script>
    <!-- bootstrap progress js -->
    <script src="<?php echo base_url('asset'); ?>/js/progressbar/bootstrap-progressbar.min.js"></script>
    <script src="<?php echo base_url('asset'); ?>/js/nicescroll/jquery.nicescroll.min.js"></script>
    <!-- icheck -->
    <script src="<?php echo base_url('asset'); ?>/js/icheck/icheck.min.js"></script>

    <script src="<?php echo base_url('asset'); ?>/js/custom.js"></script>
<!-- Menu Toggle Script -->
<script>
  $("#menu-toggle").click(function(e) {
    e.preventDefault();
    $("#wrapper").toggleClass("toggled");
  });
</script>



</body>

</html>